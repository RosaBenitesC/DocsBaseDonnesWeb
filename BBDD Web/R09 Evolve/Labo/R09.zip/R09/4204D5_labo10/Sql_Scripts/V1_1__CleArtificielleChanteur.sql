
	-- Nouvelle colonne pour la PK et la FK

	
	-- Supprimer les anciennes contraintes FK puis PK (attention, l'ordre de suppression est important ici)
	

	
	-- Nouvelles contraintes PK puis FK
	

	
	-- Remplir la nouvelle colonne FK
	

	
	-- Supprimer l'ancienne colonne FK (On veut garder le nom des chanteurs, donc on ne supprime pas l'ancienne PK !)
	

	