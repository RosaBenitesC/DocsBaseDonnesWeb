﻿using _4204D5_labo10.Models;

namespace _4204D5_labo10.ViewModels
{
    public class ChanteurEtNbChansonsViewModel
    {
        public Chanteur Chanteur { get; set; } = null!;

        public int NbChansons { get; set; }
    }
}
