﻿using _4204D5_labo10.Models;

namespace _4204D5_labo10.ViewModels
{
    public class ChanteursChansonsViewModel
    {
        public List<Chanteur> Chanteurs { get; set; } = null!;
        public List<Chanson> Chansons { get; set; } = null!;
    }
}
