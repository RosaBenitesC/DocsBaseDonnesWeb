﻿using Rencontre08.Models;

namespace Rencontre08.ViewModels
{
    public class ArtisteEmployeViewModel
    {
        public Artiste Artiste { get; set; } = null!;
        public Employe Employe { get; set; } = null!;
    }
}
