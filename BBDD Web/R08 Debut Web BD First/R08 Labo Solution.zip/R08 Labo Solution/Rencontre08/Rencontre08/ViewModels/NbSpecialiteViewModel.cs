﻿namespace Rencontre08.ViewModels
{
    public class NbSpecialiteViewModel
    {
        public string? Specialite { get; set; } 
        public int? Nb { get; set; }
    }
}
